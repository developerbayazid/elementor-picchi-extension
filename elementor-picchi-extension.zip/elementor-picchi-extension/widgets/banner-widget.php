<?php
/**
 *  
 * Elementor Banner Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Banner_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'Banner';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Banner', 'picchi-extension' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Banner widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Register Banner widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'picchi-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// Sub Heading
		$this->add_control(
			'sub_heading',
			[
				'label' => __( 'Sub Heading', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Add Your Sub Heading Text Here',
				'separator' => 'before',
				'placeholder' => __( 'Add Your Sub Heading Text Here', 'picchi-extension' ),
			]
		);

		// Heading
		$this->add_control(
			'heading',
			[
				'label' => __( 'Heading', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Add Your Heading Text Here',
				'separator' => 'before',
				'placeholder' => __( 'Add Your Heading Text Here', 'picchi-extension' ),
			]
		);

		// Description
		$this->add_control(
			'description',
			[
				'label' => __( 'Description', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'separator' => 'before',
				'default' => 'Add Your Description Text Here',
				'placeholder' => __( 'Add Your Description Text Here', 'picchi-extension' ),
			]
		);

		// Button 1 Text
		$this->add_control(
			'btn1_text',
			[
				'label' => __( 'Button 1 Text', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'separator' => 'before',
				'default' => 'Learn More',
				'placeholder' => __( 'Type Or Paste Your Button TEXT', 'picchi-extension' ),
			]
		);

		// Button 1 Link
		$this->add_control(
			'btn1_link',
			[
				'label' => __( 'Button 1 Link', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'separator' => 'before',
				'placeholder' => __( 'Type Or Paste Your Button URL', 'picchi-extension' ),
			]
		);

		// Button 2 Text
		$this->add_control(
			'btn2_text',
			[
				'label' => __( 'Button 2 Text', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'separator' => 'before',
				'default' => 'Contact Us',
				'placeholder' => __( 'Type Or Paste Your Button TEXT', 'picchi-extension' ),
			]
		);

		// Button 2 Link
		$this->add_control(
			'btn2_link',
			[
				'label' => __( 'Button 2 Link', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'separator' => 'before',
				'placeholder' => __( 'Type Or Paste Your Button URL', 'picchi-extension' ),
			]
		);
		$this->end_controls_section();

		// Style Tab
		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Style', 'picchi-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Sub Title Style 
		$this->add_control(
			'sub_heading_style_heading',
			[
				'label' => __( 'Sub Heading Style', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Sub Title Color 
		$this->add_control(
			'sub_heading_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .banner h4' => 'color: {{VALUE}}',
				],
			]
		);

		// Sub Title Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sub_heading_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .banner h4',
			]
		);

		//Title Style 
		$this->add_control(
			'heading_style_heading',
			[
				'label' => __( 'Title Style', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Title Color
		$this->add_control(
			'heading_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .banner h1' => 'color: {{VALUE}}',
				],
			]
		);

		// Title Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .banner h1',
			]
		);

		//Description Style 
		$this->add_control(
			'description_style_heading',
			[
				'label' => __( 'Description Style', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Descripton Color 
		$this->add_control(
			'description_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .banner p' => 'color: {{VALUE}}',
				],
			]
		);

		// Descripton Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .banner p',
			]
		);

		//Button 1 Title 
		$this->add_control(
			'btn1_style_heading',
			[
				'label' => __( 'Button 1', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Button 1 Style 
		$this->start_controls_tabs(
			'style_tabs'
		);

		// Noraml Style Tab 
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'picchi-extension' ),
			]
		);

		// Button 1 Color
		$this->add_control(
			'btn1_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .box-btn' => 'color: {{VALUE}}',
				],
			]
		);

		// Button 1 Background Color
		$this->add_control(
			'btn1_background_color',
			[
				'label' => __( 'Background Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#CB2D11',
				'selectors' => [
					'{{WRAPPER}} .box-btn' => 'background-color: {{VALUE}}',
				],
			]
		);

		// Button 1 Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn1_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .box-btn',
			]
		);

		// Button 1 Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn1_border',
				'label' => __( 'Border', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .box-btn',
			]
		);

		// Button 1 Border Radius
		$this->add_control(
			'btn1_border_radius_padding',
			[
				'label' => __( 'Border Radius', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button 1 Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'btn1_box_shadow',
				'label' => __( 'Box Shadow', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .box-btn',
			]
		);

		// Button 1 Padding
		$this->add_control(
			'btn1_padding',
			[
				'label' => __( 'Padding', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// Hover Style Tab
		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'picchi-extension' ),
			]
		);

		// Button 1 Hover Color
		$this->add_control(
			'btn1_hover_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .box-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		// Button 1 Background Hover Color
		$this->add_control(
			'btn1_hover_background_color',
			[
				'label' => __( 'Background Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#D35400',
				'selectors' => [
					'{{WRAPPER}} .box-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		// Button 1 Hover Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn1_hover_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .box-btn:hover',
			]
		);

		// Button 1 Hover Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn1_hover_border',
				'label' => __( 'Border', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .box-btn:hover',
			]
		);

		// Button 1 Hover Border Radius
		$this->add_control(
			'btn1_hover_border_radius',
			[
				'label' => __( 'Border Radius', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button 1 Hover Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'btn1_hover_box_shadow',
				'label' => __( 'Box Shadow', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .box-btn:hover',
			]
		);

		// Button 1 Hover Padding
		$this->add_control(
			'btn1_hover_padding',
			[
				'label' => __( 'Padding', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();



		//Button 2 Title 
		$this->add_control(
			'btn2_style_heading',
			[
				'label' => __( 'Button 2', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// Button 2 Style 
		$this->start_controls_tabs(
			'btn2_style_tabs'
		);

		// Noraml Style Tab 
		$this->start_controls_tab(
			'btn2_style_normal_tab',
			[
				'label' => __( 'Normal', 'picchi-extension' ),
			]
		);

		// Button 2 Color
		$this->add_control(
			'btn2_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .border-btn' => 'color: {{VALUE}}',
				],
			]
		);

		// Button 2 Background Color
		$this->add_control(
			'btn2_background_color',
			[
				'label' => __( 'Background Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .border-btn' => 'background-color: {{VALUE}}',
				],
			]
		);

		// Button 2 Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn2_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .border-btn',
			]
		);

		// Button 2 Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn2_border',
				'label' => __( 'Border', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .border-btn',
			]
		);

		// Button 2 Border Radius
		$this->add_control(
			'btn2_border_radius_padding',
			[
				'label' => __( 'Border Radius', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .border-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button 2 Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'btn2_box_shadow',
				'label' => __( 'Box Shadow', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .border-btn',
			]
		);

		// Button 2 Padding
		$this->add_control(
			'btn2_padding',
			[
				'label' => __( 'Padding', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .border-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// Hover Style Tab
		$this->start_controls_tab(
			'btn2_style_hover_tab',
			[
				'label' => __( 'Hover', 'picchi-extension' ),
			]
		);

		// Button 2 Hover Color
		$this->add_control(
			'btn2_hover_color',
			[
				'label' => __( 'Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .border-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);

		// Button 2 Background Hover Color
		$this->add_control(
			'btn2_hover_background_color',
			[
				'label' => __( 'Background Color', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'default' => 'tomato',
				'selectors' => [
					'{{WRAPPER}} .border-btn:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		// Button 2 Hover Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'btn2_hover_typography',
				'label' => __( 'Typography', 'picchi-extension' ),
				'scheme' => \Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPING}} .border-btn:hover',
			]
		);

		// Button 2 Hover Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn2_hover_border',
				'label' => __( 'Border', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .border-btn:hover',
			]
		);

		// Button 2 Hover Border Radius
		$this->add_control(
			'btn2_hover_border_radius',
			[
				'label' => __( 'Border Radius', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .border-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// Button 2 Hover Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'btn2_hover_box_shadow',
				'label' => __( 'Box Shadow', 'picchi-extension' ),
				'selector' => '{{WRAPPER}} .border-btn:hover',
			]
		);

		// Button 2 Hover Padding
		$this->add_control(
			'btn2_hover_padding',
			[
				'label' => __( 'Padding', 'picchi-extension' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .border-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
	 * Render Banner widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();

		$sub_heading = $settings['sub_heading'];
		$heading = $settings['heading'];
		$description = $settings['description'];
		$btn1_text = $settings['btn1_text'];
		$btn1_link = $settings['btn1_link']['url'];
		$btn2_text = $settings['btn2_text'];
		$btn2_link = $settings['btn2_link']['url'];

	?>

	<div class="banner">
		<h4><?php echo $sub_heading; ?></h4>
		<h1><?php echo $heading; ?></h1>
		<p><?php echo $description; ?></p>
		<?php if($btn1_text): ?>
			<a class="box-btn" href="<?php echo $btn1_link; ?>"><?php echo $btn1_text; ?></a>
		<?php endif; ?>
		<?php if($btn2_text): ?>
			<a class="border-btn" href="<?php echo $btn2_link; ?>"><?php echo $btn2_text; ?></a>
		<?php endif; ?>
	</div>

	<?php
	}

}
